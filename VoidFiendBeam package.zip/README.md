# VoidFiendBeam

Edits the vfx properties, and actual attack range of the Void fiend's corrupted beam.
Freely editable in the risk of options mod options menu. 


Feel free to use this mod however you like. 
